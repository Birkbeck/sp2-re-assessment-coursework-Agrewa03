/**
 * A Circle is a type of GeometricObject with a radius
 * @author Afaan Grewal
 */
public class Circle extends GeometricObject {
    private double radius;

    /**
     * Default constructor, radius = 1.0
     */
    public Circle() {
        this(1.0);
    }

    /**
     * Constructor with specified radius
     * @param radius radius of the circle
     */
    public Circle(double radius) {
        this.radius = radius;
    }

    /**
     * Constructor with radius, color and filled status
     * @param radius radius of the circle
     * @param color color of the circle
     * @param filled filled status
     */
    public Circle(double radius, String color, boolean filled) {
        super(color, filled);
        this.radius = radius;
    }

    /**
     * @return radius of the circle
     */
    public double getRadius() {
        return radius;
    }

    /**
     * @param radius set the radius of the circle
     */
    public void setRadius(double radius) {
        this.radius = radius;
    }

    /**
     * @return diameter of the circle (2 * radius)
     */
    public double getDiameter() {
        return 2 * radius;
    }

    /**
     * @return area of the circle (π * r^2)
     */
    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }

    /**
     * @return perimeter (circumference) of the circle (2 * π * r)
     */
    @Override
    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }

    /**
     * Scale the circle by multiplying radius by factor if factor > 0
     * @param factor the scale factor
     */
    @Override
    public void scale(double factor) {
        if (factor > 0) {
            radius *= factor;
        }
    }

    /**
     * @return string representation of the circle object
     */
    @Override
    public String toString() {
        return super.toString() + ", radius: " + radius;
    }
}
