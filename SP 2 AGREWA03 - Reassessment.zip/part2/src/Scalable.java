/**
 * Interface Scalable for geometric objects that can be scaled
 * @author Afaan Grewal
 */
public interface Scalable {
    /**
     * Scale the object by the specified factor
     * @param factor scaling factor
     */
    public abstract void scale(double factor);
}
