/**
 * Interface Rotatable for geometric objects that can be rotated
 * @author Afaan Grewal
 */
public interface Rotatable {
    /**
     * Rotate the object (e.g. by 90 degrees)
     */
    public abstract void rotate();
}
